#!/bin/sh
set -eu

if [ "$#" -ne 1 ]; then
    echo "Usage: sh rebuild.sh NEW_CHECKOUT_DIRECTORY" >&2
    exit 2
fi
: "${WONDERFUL_TOOLCHAIN:?Set WONDERFUL_TOOLCHAIN to the installed toolchain directory}"
: "${BLOCKSDS:=$WONDERFUL_TOOLCHAIN/thirdparty/blocksds/core}"
export WONDERFUL_TOOLCHAIN BLOCKSDS

archive_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
checkout=$1
if [ -e "$checkout" ] || [ -L "$checkout" ]; then
    echo "The checkout destination must be a new directory: $checkout" >&2
    exit 2
fi

git clone --branch archive/fusion-v0.2.3 "$archive_dir/BUNDLES/NGPDS.bundle" "$checkout"
for module in ARMZ80 K2Audio K2GE NGPFlash Shared TLCS900H; do
    git -C "$checkout" config "submodule.source/$module.url" "$archive_dir/BUNDLES/$module.bundle"
done
git -C "$checkout" -c protocol.file.allow=always submodule update --init
git -C "$checkout/source/Shared" config submodule.Unzip.url "$archive_dir/BUNDLES/Unzip.bundle"
git -C "$checkout/source/Shared" -c protocol.file.allow=always submodule update --init

test -z "$(git -C "$checkout" status --porcelain=v1 --ignore-submodules=none)"
make -C "$checkout" -j "${JOBS:-8}" COMPDB=0
(cd "$checkout" && shasum -a 256 -c "$archive_dir/EXPECTED_NDS_SHA256.txt")
test -z "$(git -C "$checkout" status --porcelain=v1 --ignore-submodules=none)"
